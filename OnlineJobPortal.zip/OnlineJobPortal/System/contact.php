<!-- CONTACT US Page-->

<!doctype html>
<html lang="en">
<!-- ADDING EXTERNAL PHP -->
<?php
include 'constants/settings.php';
include 'constants/check-login.php';
?>

<head>
	<!-- important info about the webpage -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>NepaJobs - Contact Us</title>
	

	<link rel="shortcut icon" href="images/ico/job-search.png">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" media="screen">
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/component.css" rel="stylesheet">

	
	<!-- ARE YOU A ROBOT -->
	<link href="css/style.css" rel="stylesheet">
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>


</head>
<style>
	.autofit3 {
		height: 80px;
		width: 100px;
		object-fit: cover;
	}

	.logo {
		position: relative;
		left: -50px;
		width: 150px
	}
</style>



<body class="not-transparent-header">

	<div class="container-wrapper">

		<header id="header">
			<nav class="navbar navbar-default navbar-fixed-top navbar-sticky-function">

				<div class="container">
					<!-- LOGO -->
					<div class="logo-wrapper">
						<div class="logo">
							<a href="./"><img src="images/Nepa%20jobs3.png" alt="Logo" /></a>
						</div>
					</div>

					<div id="navbar" class="navbar-nav-wrapper navbar-arrow">

						<ul class="nav navbar-nav" id="responsive-menu">

							<li>
								<!-- Down Quick Links-->
								<a href="./">Home</a>

							</li>

							<li>
								<a href="job-list.php">Job List</a>

							</li>

							<li>
								<a href="employers.php">Employers</a>
							</li>

							<li>
								<a href="employees.php">Employees</a>
							</li>

							<li>
								<a href="contact.php">Contact Us</a>
							</li>

						</ul>

					</div>

					

				</div>
				<!-- LIKE A PLACEHOLDER, CONTAINER -->
				<div id="slicknav-mobile"></div>

			</nav>
			<!-- POP UP WINDOW ON A WEBPAGE THAT DEFINES BEHAVIOR  -->
			<div id="registerModal" class="modal fade login-box-wrapper" tabindex="-1" style="display: none;"
				data-backdrop="static" data-keyboard="false" data-replace="true">
				<!-- REPRESENT HEADER SECTION OF POPUP WINDOW ON A WEB PAGE -->
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title text-center">Create your account for free</h4>
				</div>

				<div class="modal-body">

					<div class="row gap-20">
						<!-- REGISTRATION EMPLOYEE OR EMPLOYER -->
						<div class="col-sm-6 col-md-6">
							<a href="register.php?p=Employer" class="btn btn-facebook btn-block mb-5-xs">Register as
								Employer</a>
						</div>
						<div class="col-sm-6 col-md-6">
							<a href="register.php?p=Employee" class="btn btn-facebook btn-block mb-5-xs">Register as
								Employee</a>
						</div>

					</div>

				</div>

				<div class="modal-footer text-center">
					<button type="button" data-dismiss="modal" class="btn btn-primary btn-inverse">Close</button>
				</div>

			</div>



		</header>

		<div class="main-wrapper">

			<div class="breadcrumb-wrapper">

				<div class="container">

					<ol class="breadcrumb-list">
						<li><a href="./">Home</a></li>
						<li><span>Contact Us</span></li>
					</ol>

				</div>

			</div>

			<div class="section sm">

				<div class="container">

					<div class="row">

						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">

							<div class="section-title">
								<!-- TITLE: CONTACT US FOR HELP -->
								<h2><b>Contact us for help</b></h2>

							</div>

						</div>

					</div>

					<div class="row">

						<div class="col-sm-7 col-md-6 col-md-offset-1 mb-30">
							<?php include 'constants/check_reply.php'; ?>

							<form class="contact-form-wrapper" data-toggle="validator" action="app/send-message.php"
								method="POST" autocomplete="off">

								<div class="row">

									<div class="col-sm-6">
										<!-- CONTACT BOX  START HERE-->
										<div class="form-group">
											<label for="inputName">Your Name <span
													class="font10 text-danger">(required)</span></label>
											<input id="inputName" name="fullname" type="text" class="form-control"
												data-error="Your name is required" required>
											<div class="help-block with-errors"></div>
										</div>

									</div>

									<div class="col-sm-6">

										<div class="form-group">
											<label for="inputEmail">Your Email <span
													class="font10 text-danger">(required)</span></label>
											<input id="inputEmail" name="email" type="email" class="form-control"
												data-error="Your email is required and must be a valid email address"
												required>
											<div class="help-block with-errors"></div>
										</div>

									</div>


									<div class="col-sm-12">

										<div class="form-group">
											<label for="inputMessage">Message <span
													class="font10 text-danger">(required)</span></label>
											<textarea id="inputMessage" name="message" class="form-control" rows="8"
												data-minlength="50"
												data-error="Your message is required and must not less than 50 characters"
												required></textarea>
											<div class="help-block with-errors"></div>

											<!-- GOOGLE RECAPTCHA -->
											<div class="g-recaptcha"
												data-sitekey="6LfNdZYmAAAAAMyi-EwHK7ToIut_8EAxhgkwycVV"></div>
										</div>

									</div>

									<div class="col-sm-12 text-right">
										<button type="submit" class="btn btn-primary mt-5">Send Message</button>
									</div>

								</div>

							</form>

						</div>
						<!-- RIGHT SIDE INFORMATION START HERE -->
						<div class="col-sm-5 col-md-4">

							<ul class="address-list">
								<li>
									<h5>Address</h5>
									<address> Baneshwor, <br /> PO.BOX 44000, <br />New Summit College</address>
								</li>
								<li>
									<h5>Email</h5><a
										href="mailto:annishtest@gmail.com">annishtest@gmail.com</a>
								</li>
								<li>
									<h5>Phone Number</h5><a href="Phone:1234567890+">+1234567890</a>
								</li>
								<br>
								<style>
									.circular-image {
										display: flex;
										justify-content: flex-start;
									}



									.circular-image img {
										border-radius: 50%;
										width: 75px;
										height: 76px;
										object-fit: cover;
										margin-right: 18px;


									}

									.circular-image figcaption {
										text-align: center;
										margin-top: 5px;
										display: flex;
										justify-content: center;
										align-items: center;
									}
								</style>
								<!-- DEVELOPER TEAM -->
								<li>
									<h5>Developer Team</h5>
									<div class="circular-image">

										
										<a href="https://www.anishchauhan.com.np/" target="_blank"><img
												src="images/annish.jpg" alt="Twitter" class="social-icon">
											<figcaption>Anish</figcaption>
										</a>

									</div>
								</li>

							</ul>

						</div>

					</div>


				</div>

			</div>
			<!-- FOOTER START HERE -->
			<footer class="footer-wrapper">

				<div class="main-footer">

					<div class="container">

						<div class="row">

							<div class="col-sm-12 col-md-9">

								<div class="row">

									<div class="col-sm-6 col-md-4">

										<div class="footer-about-us">
											<h5 class="footer-title">About NepaJobs Jobs</h5>
											<p>NepaJobs Jobs is a job portal, online job management system developed
												in New Summit College for the project in february 2023.</p>

										</div>

									</div>

									<div class="col-sm-6 col-md-5 mt-30-xs">
										<h5 class="footer-title">Quick Links</h5>
										<ul class="footer-menu clearfix">
											<li><a href="./">Home</a></li>
											<li><a href="job-list.php">Job List</a></li>
											<li><a href="employers.php">Employers</a></li>
											<li><a href="employees.php">Employees</a></li>
											<li><a href="contact.php">Contact Us</a></li>
											<li><a href="#">Go to top</a></li>

										</ul>

									</div>

								</div>

							</div>

							<div class="col-sm-12 col-md-3 mt-30-sm">

								<h5 class="footer-title">NepaJobs Jobs Contact</h5>

								<p>Address : Shantinagar,Baneshwor</p>
								<p>Email : <a href="anishtest@gmail.com">anishtest@gmail.com</a>
								</p>
								<p>Phone : <a href="Phone:+1234567890">+1234567890</a></p>


							</div>


						</div>

					</div>

				</div>

				<div class="bottom-footer">

					<div class="container">

						<div class="row">

							<div class="col-sm-4 col-md-4">

								<p class="copy-right">&#169; Copyright
									<?php echo date('Y'); ?> NepaJobs Software
								</p>

							</div>

							<div class="col-sm-4 col-md-4">

								<ul class="bottom-footer-menu">
									<li><a>Developed by Anish</a></li>
								</ul>

							</div>

							<div class="col-sm-4 col-md-4">
								<ul class="social-media-links">

									<li><a href="https://www.anishchauhan.com.np/" target="_blank"><img
												src="images/twitter.png" alt="Twitter" class="social-icon"></a></li>
									<li><a href="https://www.anishchauhan.com.np/" target="_blank"><img
												src="images/facebook.png" alt="Twitter" class="social-icon"></a></li>
									<li><a href="https://www.anishchauhan.com.np/" target="_blank"><img
												src="images/instagram.png" alt="Twitter" class="social-icon"></a></li>
									<li><a href="https://www.youtube.com/@animeinvision116" target="_blank"><img
												src="images/youtube.png" alt="Twitter" class="social-icon"></a></li>
									<li><a href="" target="_blank"><img src="images/viber.png"
												alt="Twitter" class="social-icon"></a>
									</li>

									<style>
										.social-media-links {
											display: flex;
											justify-content: center;
											/* Align items horizontally in the center */
											align-items: center;
											/* Align items vertically in the center */

										}

										.social-media-links li {
											margin: 0 10px;
											/* Add spacing between the media links */
										}

										.social-icon {
											width: 30px;
											/* Adjust the width as desired */
											height: auto;
											/* Preserve the aspect ratio */
										}
									</style>
								</ul>
							</div>

						</div>
					</div>

				</div>

			</footer>

		</div>


	</div>


	<!-- BACK TO TOP -->
	<div id="back-to-top">
		<a href="#"><i class="ion-ios-arrow-up"></i></a>
	</div>

	
	
</body>

</html>