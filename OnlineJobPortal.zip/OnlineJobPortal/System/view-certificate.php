<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>NepaJobs - View Certificate</title>
    <link rel="shortcut icon" href="images/ico/job-search.png">
    <link href="css/main.css" rel="stylesheet">
</head>

<body>
    <?php
    require 'constants/db_config.php';
    $file_id = $_GET['id'];

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


        $stmt = $conn->prepare("SELECT * FROM tbl_professional_qualification WHERE id = :fileid");
        $stmt->bindParam(':fileid', $file_id);
        $stmt->execute();
        $result = $stmt->fetchAll();

        foreach ($result as $row) {
            $certificate = $row['certificate'];

            ?>
            <!-- Degree Image -->
            <div style="width:100%">
                <img src="images/Degre.jpg" alt="Image">

            </div>

            <?php
        }


    } catch (PDOException $e) {

    }

    ?>
</body>

</html>